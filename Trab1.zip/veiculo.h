#ifndef VEICULO_H
#define VEICULO_H

typedef struct cabecalhoVeiculo HeaderVeiculo;
typedef struct registroVeiculo RegistroVeiculo;

void func1(FILE* fp, FILE* binario);
void func3(FILE* binario);
void func5(FILE* binario, char* nomeDoCampo, char* valor);
int func7(FILE* binario, int n);

#endif
